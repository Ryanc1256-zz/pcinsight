-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 28, 2013 at 02:01 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `karl_pcinsight`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `articletext` longtext NOT NULL,
  `writer` mediumtext NOT NULL,
  `editorsTick` tinyint(1) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `tags` mediumtext NOT NULL,
  `title` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `articletext`, `writer`, `editorsTick`, `date`, `tags`, `title`) VALUES
(4, '<p style="margin-left:40px"><img data-cke-saved-src="/pcinsight/images/uploads/editors/ba00d9d80398.jpg" src="/pcinsight/images/uploads/editors/ba00d9d80398.jpg"></p><h3><strong>Introducing the SilverStone Raven RV04</strong></h3><p>The SilverStone Raven RV04 is, to put it mildly, long overdue. While announcements about its existence date back to just over a year, I can tell you this case has been in development since not long after SilverStone released their remarkably strong&nbsp;<a data-cke-saved-href="http://www.anandtech.com/show/4533/silverstone-temjin-tj08-fat-case-in-a-little-coat" href="http://www.anandtech.com/show/4533/silverstone-temjin-tj08-fat-case-in-a-little-coat">Temjin TJ08-E</a>. That case''s stellar performance surprised even SilverStone; I''m reasonably certain they thought the Fortress FT03 was going to be their strongest Micro-ATX enclosure for some time to come, but the TJ08-E changed the game. After I reviewed it, I asked them directly for an ATX version and received the kind of cagey answer I ultimately wanted to hear.</p><p style="margin-left:80px"><img data-cke-saved-src="/pcinsight/images/uploads/editors/81c6c34ff391.jpg" src="/pcinsight/images/uploads/editors/81c6c34ff391.jpg"></p><p style="margin-left:80px"><br></p><p>Unfortunately, the journey of the full-sized TJ08-E descendant has been more than a little fraught. It''s my understanding that tooling problems, among other things, have led to lengthy delays. In fact even the Raven RV04 will be showing up late on American shores; we''ll likely actually get the high end version of this chassis, the Fortress FT04, first.</p><p>The design has a lot to live up to. SilverStone''s Fortress FT02 has practically been the gold standard for air cooling for some time now, and they posit that the FT04 is actually capable of producing even better performance. Part of the reason they have this confidence is because they seem to understand a vital truth about cases and cooling that many of their contemporaries still grapple with: nothing cools better than a direct line of airflow through the CPU cooler. The rotated motherboard and convection cooling was never the magic that made the FT02 and previous Ravens work; it was good marketing and seemed sound, but the reason those cases were so good at their jobs was the fact that they had giant fans blowing directly through the CPU tower coolers. Air wasn''t moving at an angle like it does in traditional ATX cases.</p><p><br></p><p><br></p><p><br></p><table border="1" cellpadding="0" cellspacing="0"><tbody><tr><td colspan="3">SilverStone Raven RV04 Specifications</td></tr><tr><td colspan="2" style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>Motherboard Form Factor</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">Mini-ITX, Micro-ATX, ATX, E-ATX, SSI-EEB, SSI-CEB</td></tr><tr><td rowspan="2" style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>Drive Bays</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>External</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">2x 5.25"</td></tr><tr><td style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>Internal</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">7x 3.5", 4x 2.5"</td></tr><tr><td rowspan="5" style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>Cooling</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>Front</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">2x 180mm intake fan</td></tr><tr><td style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>Rear</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">1x 120mm fan mount</td></tr><tr><td style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>Top</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">-</td></tr><tr><td style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>Side</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">-</td></tr><tr><td style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>Bottom</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">-</td></tr><tr><td colspan="2" style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>Expansion Slots</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">8</td></tr><tr><td colspan="2" style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>I/O Port</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">2x USB 3.0, 1x Headphone, 1x Mic</td></tr><tr><td colspan="2" style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>Power Supply Size</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">ATX</td></tr><tr><td rowspan="3" style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>Clearances</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>HSF</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">165mm</td></tr><tr><td style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>PSU</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">~200mm with optical drive</td></tr><tr><td style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>GPU</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">338mm</td></tr><tr><td colspan="2" style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>Dimensions</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">8.62" x 22.87" x 19.57"<br>219mm x 581mm x 497mm</td></tr><tr><td colspan="2" style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>Special Features</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">USB 3.0 via internal header<br>Removable drive cages<br>Three-speed intake fans<br>Support struts for CPU fan and graphics cards<br>Window or windowless models</td></tr><tr><td colspan="2" style="background-color:rgb(238, 238, 238); vertical-align:top"><strong>Price</strong></td><td style="background-color:rgb(238, 238, 238); vertical-align:top">$159</td></tr></tbody></table><p>The Raven RV04 is, in true SilverStone fashion, kind of an oddball. But it''s an oddball even by SilverStone standards. What should strike you immediately is the fact that they&nbsp;don''t&nbsp;include a 120mm exhaust fan by default, flying in the face of conventional wisdom. This is something actually covered in their press material; by not including the 120mm exhaust fan, they''re able to let the extant front intake fans to channel air directly from front to back. The flow of air inside the RV04 winds up being defined almost entirely by the coolers used on the processor and graphics card(s). Ordinarily I pay even less attention to PR than you do, but SilverStone''s is usually pretty on the money, and without spoiling too much I can tell you that I definitely didn''t miss the exhaust fan.&nbsp;</p>', 'ryanc1256@gmail.com', 1, '2013-06-20', 'Cases,SilverStone,Atx,Cooling/PSUS', 'SilverStone Raven RV04 Case Review');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `commentID` int(11) NOT NULL AUTO_INCREMENT,
  `articleID` int(11) NOT NULL,
  `message` text NOT NULL,
  `userID` int(11) NOT NULL COMMENT 'The userID from who added the message',
  PRIMARY KEY (`commentID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`commentID`, `articleID`, `message`, `userID`) VALUES
(1, 1, 'hello', 1),
(2, 4, 'hello', 1),
(3, 4, 'hello', 1),
(4, 4, 'hello', 1),
(5, 4, 'hello', 1),
(6, 4, '<p><s>hello this is just a new comment <strong>:D so... </strong></s></p>\r\n\r\n<h1 style="font-style: italic;"><strong>This acticle is soo good :D</strong></h1>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `UserID` int(255) NOT NULL AUTO_INCREMENT,
  `username` mediumtext NOT NULL,
  `password` mediumtext NOT NULL,
  `email` mediumtext NOT NULL,
  `staff` tinyint(1) NOT NULL DEFAULT '0',
  `socialnetwork` mediumtext NOT NULL,
  `emailCheck` int(255) NOT NULL DEFAULT '0',
  `editor` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `userProfile` mediumtext NOT NULL,
  `idGen` mediumtext NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `username`, `password`, `email`, `staff`, `socialnetwork`, `emailCheck`, `editor`, `admin`, `userProfile`, `idGen`) VALUES
(1, 'Ryan Clough', '$2a$08$LRRvTltc4B3PIQ5tQNQdzOLT/ujW1RI4i0ZqNCRItRYC2guuJW1Cu', 'ryanc1256@gmail.com', 1, '0', 1, 0, 1, '/pcinsight/scripts/ajax/uploads/images/ab6a298cf4bf.jpg', '4L6GYvCWq3VEdbVcM55L'),
(2, 'LinuxUser', '$2a$08$MdcqgwFviqvFg9v7EnJVl.3nyFX8NET9hGCUXY4.Gg608X1yzRsk6', 'karl@scowencomputers.co.nz', 1, '0', 0, 1, 1, '', ''),
(3, 'tehkhop', '$2a$08$oHK3B5ziwXLLNxKljKXta.Pht2Wwm9dB5CoewC1Cg9tK5pqujNcQu', 'lachlan__davidson@hotmail.com', 0, '0', 0, 0, 0, '', ''),
(4, 'test', '$2a$08$Q.8pLKJ96DakZGXB4tHOmOIB1XsqbBhAwfwBIFWnB.owL.Z5Px9MW', 'test1@test.com', 0, '0', 0, 0, 0, '', 'k62g3zK5r1wiYmyMmVAu'),
(5, 'GamernzHenry', '$2a$08$taIKQUcSQyo.g7Oxca7Qd.J5nNH/zdKPThB1xtW.d1A1Cs0X5fuua', 'gamernz@hotmail.co.nz', 0, '0', 0, 0, 0, '', 't0jVWnUBIc2uw24KzFmY'),
(6, 'Josh Hunter', '$2a$08$4GwGhu4fixBwI4aNAv2eIuS.wwKUzrooleQUSMu6ckaTmrKwlZ/jG', 'josh.hunter@hotmail.co.nz', 0, '0', 0, 0, 0, '', 'tvYXoCk3YJD8w17EWgS7');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
